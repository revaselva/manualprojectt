package TestNG;

import org.testng.annotations.Test;

import pom_PageObjectModel.Open_Mrs;

import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;

public class DDT_OpenMrs
{
	WebDriver driver;
	@BeforeTest
	public void beforeTest() 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\Automation Testing\\Bowser Extension\\edgedriver.exe");
		driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

	}

	@Test(dataProvider = "dp")
	public void openMRS(String usn, String pwd) throws Exception 
	{
		Open_Mrs o=new Open_Mrs();
		o.maximizeBrowser(driver);
		Thread.sleep(2000);
		o.getUrl(driver);
		Thread.sleep(2000);
		o.enterUsername(driver,usn);
		Thread.sleep(2000);
		o.enterPassword(driver,pwd);
		Thread.sleep(2000);
		o.clickOnLocation(driver);
		Thread.sleep(2000);
		o.clickOnLogin(driver);
		Thread.sleep(2000);
		o.clickOnLogout(driver); 
	}

	@DataProvider
	public Object[][] dp() 
	{
		return new Object[][] {
			new Object[] { "Admin", "Admin123" },
			new Object[] { "System", "sys@123" },
			new Object[] { "Edubridge", "edu@11" },
			new Object[] { "admin", "admin123" },
			new Object[] { "Sairamya", "sai@123" },
			new Object[] { "Admin", "admin123" },

		};
	}
	

	@AfterTest
	public void afterTest() 
	{
		driver.close();
	}

}
