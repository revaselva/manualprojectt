package KDT;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;


public class Mainclass
{

	public static void main(String[] args) throws Throwable
	{
	
		//launch browser
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\Automation Testing\\Browser Extension\\edgedriver.exe");
		WebDriver driver=new EdgeDriver();
		Thread.sleep(2000);

		System.out.println("hai");
		//create object of Readexcelclass
		Readexcelclass r=new Readexcelclass();
		r.readexcel();
	
		
		

	}

}
