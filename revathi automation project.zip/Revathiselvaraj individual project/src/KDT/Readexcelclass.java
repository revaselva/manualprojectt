package KDT;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbookFactory;
import org.openqa.selenium.WebDriver;




public class Readexcelclass
{
	
	public void readexcel() throws Throwable  
	{
	FileInputStream file=new FileInputStream("C:\\Users\\HP\\Desktop\\Automation Testing\\Eclipse Backup\\OpenMrs_project\\Resources\\poi_Theory\\poi_Theory.xlsx");
	XSSFWorkbook w= new XSSFWorkbook(file);
    XSSFSheet s= w.getSheet("KDT");
    
    int rowSize=s.getLastRowNum();
    System.out.println("No Of Keywords: "+rowSize);
    Operationalclass o=new Operationalclass();
    
    for(int i=1;i<=rowSize;i++)
    {
    	
    	
    	String key=s.getRow(i).getCell(0).getStringCellValue();
    	System.out.println(key);
    	
    	if(key.equals("OpenURL"))
    	{
    		o.getUrl();
    		Thread.sleep(2000);
    	}
    	else if(key.equals("MaximizeBrowser"))
    	{
    		o.maximizeBrowser();
    		Thread.sleep(2000);
    	}
    	else if(key.equals("EnterUsername"))
    	{
    		o.enterUsername("Admin");
    		Thread.sleep(2000);
    	}
    	else if(key.equals("EnterPassword"))
    	{
    		o.enterPassword("Admin123");
    		Thread.sleep(2000);
    	}
    	else if(key.equals("ClickOnLocation"))
    	{
            o.clickOnLocation();
    		Thread.sleep(2000);
    	}
    	else if(key.equals("ClickOnLogin"))
    	{
    		o.clickOnLogin();
    		Thread.sleep(2000);
    	}
    	else if(key.equals("ClickOnLogout"))
    	{
    		o.clickOnLogout();
    		Thread.sleep(2000);
    	}
    	else if(key.equals("CloseBrowser"))
    	{
    		o.closeBrowser();
    	}
    }
}
}

